﻿

using System;

namespace Business_Rule_Engine
{
    interface IRuleEngine
    {
        bool ProcessOrder(int OrderId);
    }

    public class PhysicalProductPayment : IRuleEngine
    {
        public bool ProcessOrder(int OrderId)
        {
            Console.WriteLine("Packing slip generated for shipping"); //Write code here to generate a packing slip for shipping.
            return true;
        }
    }

    public class BookPayment : IRuleEngine
    {
        public bool ProcessOrder(int OrderId)
        {
            Console.WriteLine("Created duplicate packing slip for royalty");//Write code here to create a duplicate packing slips for the royalty department.
            return true;
        }
    }


    public class MembershipPayment : IRuleEngine
    {
        public bool ProcessOrder(int OrderId)
        {
            Console.WriteLine("Membership activated");//Write code here to activate the membership.
            return true;
        }
    }

    public class UpgradeMembershipPayment : IRuleEngine
    {
        public bool ProcessOrder(int OrderId)
        {
            Console.WriteLine("Membership upgrated");//Write code here to apply upgrade.
            return true;
        }
    }

    public class MembershipOrUpgradePayment : IRuleEngine
    {
        public bool ProcessOrder(int OrderId)
        {
            Console.WriteLine("Sent mail to owner and informed for the activation/upgrade ");//Write code here to e-mail the owner and inform them of the activation/upgrade.
            return true;
        }
    }

    public class VideoPayment : IRuleEngine
    {
        public bool ProcessOrder(int OrderId)
        {
            Console.WriteLine("Added free First Aid video to the packing slip (the result of a court decision in 1997).");//Write code here to "Learning to Ski", add free "First Aid" video to the packing slip (the result of a court decision in 1997)
            return true;
        }
    }

    public class PhysicalProductOrBookPayment : IRuleEngine
    {
        public bool ProcessOrder(int OrderId)
        {
            Console.WriteLine("Generated commision payment to agent");//Write code here to generate a commission payment to the agent.
            return true;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("01 : Payment is for Physical Product.");
            Console.WriteLine("02 : Payment is for Book.");
            Console.WriteLine("03 : Payment is for Membership.");
            Console.WriteLine("04 : Payment is for an upgrade to a membership.");
            Console.WriteLine("05 : Payment is for membership or upgrade.");
            Console.WriteLine("06 : Payment is for the video Learning to Ski.");
            Console.WriteLine("07 : Payment is for physical product or a book.");
            Console.WriteLine("Please enter the payment method from the above.");
            var input = Console.ReadLine();

            IRuleEngine ruleEngine;

            switch (input)
            {
                case "01":
                    ruleEngine = new PhysicalProductPayment();
                    ruleEngine.ProcessOrder(1);
                    return;

                case "02":
                    ruleEngine = new BookPayment();
                    ruleEngine.ProcessOrder(1);
                    return;

                case "03":
                    ruleEngine = new MembershipPayment();
                    ruleEngine.ProcessOrder(1);
                    return;

                case "04":
                    ruleEngine = new UpgradeMembershipPayment();
                    ruleEngine.ProcessOrder(1);
                    return;

                case "05":
                    ruleEngine = new MembershipOrUpgradePayment();
                    ruleEngine.ProcessOrder(1);
                    return;

                case "06":
                    ruleEngine = new VideoPayment();
                    ruleEngine.ProcessOrder(1);
                    return;

                case "07":
                    ruleEngine = new PhysicalProductOrBookPayment();
                    ruleEngine.ProcessOrder(1);
                    return;

                default:
                    Console.WriteLine("Please enter a valid input.");
                    break;
            }

            Console.WriteLine("");
        }
    }
}